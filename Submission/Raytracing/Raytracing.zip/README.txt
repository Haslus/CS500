/* ---------------------------------------------------------------------------------------------------------
Copyright (C) 2020 DigiPen Institute of Technology.
Reproduction or disclosure of this file or its contents without the prior written
consent of DigiPen Institute of Technology is prohibited.
Project: cs500_asier.b_1
Author: Asier Bilbao / asier.b
Creation date: 1/20/2020
----------------------------------------------------------------------------------------------------------*/
� How to run your program: Visual Studio 2017 x64
� How to use your program: First argument is width, second is heigth, third is the input file, and fourth is output file
You can change some parameters on the config file.
HARD_SHADOWS has preference over SOFT_SHADOWS, so if HARD_SHADOWS is true, SOFT_SHADOWS is not executed.

� Important parts of the code: Collision and Scene has the important stuff.
� Known issues and problems: No problems.